using CleverRoom.Data;
using CleverRoom.Models;
using CleverRoom.Models.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CleverRoom.Controllers
{
    public class HomeController : Controller
    {
        private readonly ApplicationDbContext _db;
        private readonly UserManager<ApplicationUser> _userManager;

        public HomeController(ApplicationDbContext db, UserManager<ApplicationUser> userManager)
        {
            _db = db;
            _userManager = userManager;
        }

        public async Task<IActionResult> Index()
        {
            var upcoming = await _db.Trainings
                .Where(t => t.Status == TrainingStatus.Published)
                .OrderBy(t => t.StartDate)
                .Take(3)
                .Include(t => t.Author)
                .ToListAsync();

            var reviews = await _db.Reviews
                .Where(r => !r.IsHidden)
                .OrderByDescending(r => r.CreatedAt)
                .Take(6)
                .Include(r => r.Author)
                .ToListAsync();

            ViewBag.Upcoming = upcoming;
            ViewBag.Reviews = reviews;
            return View();
        }

        public IActionResult Contacts() => View();

        public async Task<IActionResult> Reviews()
        {
            var reviews = await _db.Reviews
                .Where(r => !r.IsHidden)
                .OrderByDescending(r => r.CreatedAt)
                .Include(r => r.Author)
                .ToListAsync();
            return View(reviews);
        }

        [Authorize]
        [HttpGet]
        public IActionResult AddReview() => View(new ReviewFormViewModel());

        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddReview(ReviewFormViewModel model)
        {
            if (!ModelState.IsValid) return View(model);

            var userId = _userManager.GetUserId(User)!;
            var review = new Review
            {
                Content = model.Content,
                Rating = model.Rating,
                AuthorId = userId
            };

            _db.Reviews.Add(review);
            await _db.SaveChangesAsync();
            TempData["Success"] = "Отзивът беше добавен успешно.";
            return RedirectToAction(nameof(Reviews));
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error() => View();
    }
}
