using CleverRoom.Data;
using CleverRoom.Models;
using CleverRoom.Models.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CleverRoom.Controllers
{
    public class TrainingController : Controller
    {
        private readonly ApplicationDbContext _db;
        private readonly UserManager<ApplicationUser> _userManager;

        public TrainingController(ApplicationDbContext db, UserManager<ApplicationUser> userManager)
        {
            _db = db;
            _userManager = userManager;
        }

        // ---------- Public listings ----------

        public async Task<IActionResult> Upcoming()
        {
            var list = await _db.Trainings
                .Where(t => t.Status == TrainingStatus.Published && t.StartDate > DateTime.UtcNow)
                .Include(t => t.Author)
                .Include(t => t.Enrollments)
                .OrderBy(t => t.StartDate)
                .ToListAsync();
            return View(list);
        }

        public async Task<IActionResult> Active()
        {
            var list = await _db.Trainings
                .Where(t => t.Status == TrainingStatus.Active)
                .Include(t => t.Author)
                .Include(t => t.Enrollments)
                .OrderBy(t => t.StartDate)
                .ToListAsync();
            return View(list);
        }

        public async Task<IActionResult> Completed()
        {
            var list = await _db.Trainings
                .Where(t => t.Status == TrainingStatus.Completed)
                .Include(t => t.Author)
                .Include(t => t.Enrollments)
                .OrderByDescending(t => t.StartDate)
                .ToListAsync();
            return View(list);
        }

        // ---------- Details ----------

        public async Task<IActionResult> Details(int id)
        {
            var training = await _db.Trainings
                .Include(t => t.Author)
                .Include(t => t.Enrollments).ThenInclude(e => e.User)
                .Include(t => t.Comments.Where(c => !c.IsHidden)).ThenInclude(c => c.Author)
                .FirstOrDefaultAsync(t => t.Id == id);

            if (training == null) return NotFound();

            var userId = _userManager.GetUserId(User);
            var isEnrolled = userId != null && training.Enrollments.Any(e => e.UserId == userId && e.IsActive);
            var isAuthor = userId == training.AuthorId;

            ViewBag.IsEnrolled = isEnrolled;
            ViewBag.IsAuthor = isAuthor;
            ViewBag.UserId = userId;
            ViewBag.CommentForm = new CommentFormViewModel { TrainingId = id };
            return View(training);
        }

        // ---------- Create ----------

        [Authorize]
        [HttpGet]
        public IActionResult Create() => View(new TrainingFormViewModel());

        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(TrainingFormViewModel model)
        {
            if (!ModelState.IsValid) return View(model);

            var userId = _userManager.GetUserId(User)!;
            var training = new Training
            {
                Title = model.Title,
                Description = model.Description,
                StartDate = model.StartDate,
                EnrollmentDeadline = model.EnrollmentDeadline,
                MinParticipants = model.MinParticipants,
                MaxParticipants = model.MaxParticipants,
                ImageUrl = model.ImageUrl,
                VideoUrl = model.VideoUrl,
                Location = model.Location,
                AuthorId = userId,
                Status = TrainingStatus.PendingApproval
            };

            _db.Trainings.Add(training);
            await _db.SaveChangesAsync();
            TempData["Success"] = "Обучението е изпратено за одобрение.";
            return RedirectToAction(nameof(MyTrainings));
        }

        // ---------- Edit ----------

        [Authorize]
        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            var training = await _db.Trainings.FindAsync(id);
            if (training == null) return NotFound();

            var userId = _userManager.GetUserId(User);
            var isAdmin = User.IsInRole("Admin");

            if (training.AuthorId != userId && !isAdmin)
                return Forbid();

            var model = new TrainingFormViewModel
            {
                Id = training.Id,
                Title = training.Title,
                Description = training.Description,
                StartDate = training.StartDate,
                EnrollmentDeadline = training.EnrollmentDeadline,
                MinParticipants = training.MinParticipants,
                MaxParticipants = training.MaxParticipants,
                ImageUrl = training.ImageUrl,
                VideoUrl = training.VideoUrl,
                Location = training.Location
            };
            return View(model);
        }

        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(TrainingFormViewModel model)
        {
            if (!ModelState.IsValid) return View(model);

            var training = await _db.Trainings.FindAsync(model.Id);
            if (training == null) return NotFound();

            var userId = _userManager.GetUserId(User);
            var isAdmin = User.IsInRole("Admin");

            if (training.AuthorId != userId && !isAdmin)
                return Forbid();

            training.Title = model.Title;
            training.Description = model.Description;
            training.StartDate = model.StartDate;
            training.EnrollmentDeadline = model.EnrollmentDeadline;
            training.MinParticipants = model.MinParticipants;
            training.MaxParticipants = model.MaxParticipants;
            training.ImageUrl = model.ImageUrl;
            training.VideoUrl = model.VideoUrl;
            training.Location = model.Location;

            await _db.SaveChangesAsync();
            TempData["Success"] = "Обучението беше обновено успешно.";
            return RedirectToAction(nameof(Details), new { id = model.Id });
        }

        // ---------- Delete ----------

        [Authorize(Roles = "Admin")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            var training = await _db.Trainings.FindAsync(id);
            if (training == null) return NotFound();

            _db.Trainings.Remove(training);
            await _db.SaveChangesAsync();
            TempData["Success"] = "Обучението беше изтрито.";
            return RedirectToAction(nameof(Upcoming));
        }

        // ---------- Enroll ----------

        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Enroll(int id)
        {
            var training = await _db.Trainings
                .Include(t => t.Enrollments)
                .FirstOrDefaultAsync(t => t.Id == id);

            if (training == null) return NotFound();

            var userId = _userManager.GetUserId(User)!;

            if (!training.CanEnroll)
            {
                TempData["Error"] = "Записването не е възможно в момента.";
                return RedirectToAction(nameof(Details), new { id });
            }

            if (training.Enrollments.Any(e => e.UserId == userId))
            {
                TempData["Error"] = "Вече сте записан/а за това обучение.";
                return RedirectToAction(nameof(Details), new { id });
            }

            _db.Enrollments.Add(new Enrollment { UserId = userId, TrainingId = id });
            await _db.SaveChangesAsync();
            TempData["Success"] = "Записахте се успешно.";
            return RedirectToAction(nameof(Details), new { id });
        }

        // ---------- Comments ----------

        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddComment(CommentFormViewModel model)
        {
            if (!ModelState.IsValid)
                return RedirectToAction(nameof(Details), new { id = model.TrainingId });

            var training = await _db.Trainings
                .Include(t => t.Enrollments)
                .FirstOrDefaultAsync(t => t.Id == model.TrainingId);

            if (training == null) return NotFound();

            var userId = _userManager.GetUserId(User)!;
            bool canComment = (training.Status == TrainingStatus.Active || training.Status == TrainingStatus.Completed)
                              && (training.AuthorId == userId || training.Enrollments.Any(e => e.UserId == userId && e.IsActive));

            if (!canComment)
            {
                TempData["Error"] = "Нямате право да коментирате това обучение.";
                return RedirectToAction(nameof(Details), new { id = model.TrainingId });
            }

            _db.Comments.Add(new Comment
            {
                Content = model.Content,
                AuthorId = userId,
                TrainingId = model.TrainingId
            });
            await _db.SaveChangesAsync();
            TempData["Success"] = "Коментарът беше добавен.";
            return RedirectToAction(nameof(Details), new { id = model.TrainingId });
        }

        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> FlagComment(int commentId, int trainingId)
        {
            var comment = await _db.Comments
                .Include(c => c.Training)
                .FirstOrDefaultAsync(c => c.Id == commentId);

            if (comment == null) return NotFound();

            var userId = _userManager.GetUserId(User)!;
            if (comment.Training!.AuthorId != userId)
                return Forbid();

            comment.IsFlagged = true;
            await _db.SaveChangesAsync();
            TempData["Success"] = "Коментарът беше маркиран за преглед от администратор.";
            return RedirectToAction(nameof(Details), new { id = trainingId });
        }

        // ---------- My Trainings ----------

        [Authorize]
        public async Task<IActionResult> MyTrainings()
        {
            var userId = _userManager.GetUserId(User)!;

            var asAuthor = await _db.Trainings
                .Where(t => t.AuthorId == userId && t.Status != TrainingStatus.Completed)
                .Include(t => t.Enrollments)
                .OrderBy(t => t.StartDate)
                .ToListAsync();

            var asParticipant = await _db.Enrollments
                .Where(e => e.UserId == userId && e.IsActive
                    && e.Training!.Status != TrainingStatus.Completed)
                .Include(e => e.Training).ThenInclude(t => t!.Author)
                .Select(e => e.Training!)
                .OrderBy(t => t.StartDate)
                .ToListAsync();

            var completed = await _db.Trainings
                .Where(t => (t.AuthorId == userId || t.Enrollments.Any(e => e.UserId == userId))
                            && t.Status == TrainingStatus.Completed)
                .Include(t => t.Author)
                .OrderByDescending(t => t.StartDate)
                .ToListAsync();

            var vm = new MyTrainingsViewModel
            {
                AsAuthor = asAuthor,
                AsParticipant = asParticipant,
                Completed = completed
            };
            return View(vm);
        }
    }
}
