using CleverRoom.Data;
using CleverRoom.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CleverRoom.Controllers
{
    [Authorize(Roles = "Admin")]
    public class AdminController : Controller
    {
        private readonly ApplicationDbContext _db;

        public AdminController(ApplicationDbContext db)
        {
            _db = db;
        }

        public async Task<IActionResult> Index()
        {
            ViewBag.PendingCount = await _db.Trainings
                .CountAsync(t => t.Status == TrainingStatus.PendingApproval);
            ViewBag.FlaggedCount = await _db.Comments
                .CountAsync(c => c.IsFlagged && !c.IsHidden);
            ViewBag.TotalUsers = await _db.Users.CountAsync();
            return View();
        }

        // ---------- Trainings management ----------

        public async Task<IActionResult> PendingTrainings()
        {
            var list = await _db.Trainings
                .Where(t => t.Status == TrainingStatus.PendingApproval)
                .Include(t => t.Author)
                .OrderBy(t => t.CreatedAt)
                .ToListAsync();
            return View(list);
        }

        public async Task<IActionResult> AllTrainings()
        {
            var list = await _db.Trainings
                .Include(t => t.Author)
                .Include(t => t.Enrollments)
                .OrderByDescending(t => t.CreatedAt)
                .ToListAsync();
            return View(list);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Approve(int id)
        {
            var training = await _db.Trainings.FindAsync(id);
            if (training == null) return NotFound();

            training.Status = TrainingStatus.Published;
            await _db.SaveChangesAsync();
            TempData["Success"] = $"Обучение „{training.Title}" е одобрено и публикувано.";
            return RedirectToAction(nameof(PendingTrainings));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ChangeStatus(int id, TrainingStatus status)
        {
            var training = await _db.Trainings
                .Include(t => t.Enrollments)
                .FirstOrDefaultAsync(t => t.Id == id);

            if (training == null) return NotFound();

            // Auto-cancel if below min participants and past deadline
            if (status == TrainingStatus.Active
                && training.EnrolledCount < training.MinParticipants
                && DateTime.UtcNow > training.EnrollmentDeadline)
            {
                training.Status = TrainingStatus.Canceled;
                TempData["Info"] = "Обучението е отказано поради недостатъчен брой участници.";
            }
            else
            {
                training.Status = status;
                TempData["Success"] = "Статусът беше обновен.";
            }

            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(AllTrainings));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteTraining(int id)
        {
            var training = await _db.Trainings.FindAsync(id);
            if (training != null)
            {
                _db.Trainings.Remove(training);
                await _db.SaveChangesAsync();
                TempData["Success"] = "Обучението беше изтрито.";
            }
            return RedirectToAction(nameof(AllTrainings));
        }

        // ---------- Comments management ----------

        public async Task<IActionResult> FlaggedComments()
        {
            var list = await _db.Comments
                .Where(c => c.IsFlagged && !c.IsHidden)
                .Include(c => c.Author)
                .Include(c => c.Training)
                .OrderByDescending(c => c.CreatedAt)
                .ToListAsync();
            return View(list);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> HideComment(int id)
        {
            var comment = await _db.Comments.FindAsync(id);
            if (comment != null)
            {
                comment.IsHidden = true;
                await _db.SaveChangesAsync();
                TempData["Success"] = "Коментарът беше скрит.";
            }
            return RedirectToAction(nameof(FlaggedComments));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DismissFlag(int id)
        {
            var comment = await _db.Comments.FindAsync(id);
            if (comment != null)
            {
                comment.IsFlagged = false;
                await _db.SaveChangesAsync();
                TempData["Success"] = "Флагът беше премахнат.";
            }
            return RedirectToAction(nameof(FlaggedComments));
        }

        // ---------- Reviews management ----------

        public async Task<IActionResult> AllReviews()
        {
            var list = await _db.Reviews
                .Include(r => r.Author)
                .OrderByDescending(r => r.CreatedAt)
                .ToListAsync();
            return View(list);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> HideReview(int id)
        {
            var review = await _db.Reviews.FindAsync(id);
            if (review != null)
            {
                review.IsHidden = true;
                await _db.SaveChangesAsync();
                TempData["Success"] = "Отзивът беше скрит.";
            }
            return RedirectToAction(nameof(AllReviews));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteReview(int id)
        {
            var review = await _db.Reviews.FindAsync(id);
            if (review != null)
            {
                _db.Reviews.Remove(review);
                await _db.SaveChangesAsync();
                TempData["Success"] = "Отзивът беше изтрит.";
            }
            return RedirectToAction(nameof(AllReviews));
        }
    }
}
