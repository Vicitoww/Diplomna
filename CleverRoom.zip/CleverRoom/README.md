# CleverRoom – Платформа за управление на събития и обучения

## Технологии
- ASP.NET Core 8 MVC
- Entity Framework Core 8 (Code First)
- ASP.NET Core Identity
- SQL Server (LocalDB за разработка)
- Razor Views (HTML без JavaScript)

## Структура на проекта

```
CleverRoom/
├── Controllers/
│   ├── AccountController.cs    # Регистрация, Вход, Изход
│   ├── HomeController.cs       # Начало, Отзиви, Контакти
│   ├── TrainingController.cs   # CRUD обучения, Записване, Коментари
│   └── AdminController.cs      # Одобрение, Статуси, Модерация
├── Models/
│   ├── ApplicationUser.cs
│   ├── Training.cs             # Статуси: PendingApproval/Published/Active/Completed/Canceled
│   ├── Enrollment.cs           # + Comment.cs + Review.cs
│   └── ViewModels/
│       └── ViewModels.cs
├── Data/
│   ├── ApplicationDbContext.cs
│   └── DbSeeder.cs
├── Views/
│   ├── Shared/_Layout.cshtml
│   ├── Account/  (Register, Login, AccessDenied)
│   ├── Training/ (Upcoming, Active, Completed, Details, Create, Edit, MyTrainings)
│   ├── Home/     (Index, Reviews, AddReview, Contacts)
│   └── Admin/    (Index, PendingTrainings, AllTrainings, FlaggedComments, AllReviews)
└── wwwroot/css/site.css
```

## Стартиране

### 1. Изисквания
- .NET 8 SDK
- SQL Server LocalDB (включен с Visual Studio)

### 2. Конфигурация на база данни

В `appsettings.json` е зададена connection string за LocalDB:
```json
"DefaultConnection": "Server=(localdb)\\mssqllocaldb;Database=CleverRoomDb;Trusted_Connection=True"
```

### 3. Миграции и стартиране

```bash
cd CleverRoom
dotnet ef migrations add InitialCreate
dotnet run
```

При стартиране приложението автоматично:
- Прилага миграциите
- Създава роли Admin и User
- Сийдва тест потребители

### 4. Тест акаунти

| Роля  | Имейл               | Парола   |
|-------|---------------------|----------|
| Admin | admin@cleverroom.bg | Admin@123 |
| User  | user@cleverroom.bg  | User@123  |

## Функционалности

### Потребител (User)
- Регистрация и вход
- Предлагане на ново обучение (→ PendingApproval)
- Записване за обучения (Published, преди краен срок)
- Коментари в Active/Completed обучения (само участници/автор)
- Флагване на коментари (само лектор на обучението)
- Писане на отзиви за платформата
- Секция „Моите курсове" (като лектор / курсист / завършили)

### Администратор (Admin)
- Всички права на User
- Одобрение на чакащи обучения
- Промяна на статус на всяко обучение
- Редактиране и изтриване на обучения
- Преглед и реакция на маркирани (flagged) коментари
- Скриване/изтриване на отзиви

### Жизнен цикъл на обучение
```
PendingApproval → Published → Active → Completed
                                     → Canceled (при < MinParticipants преди deadline)
```
