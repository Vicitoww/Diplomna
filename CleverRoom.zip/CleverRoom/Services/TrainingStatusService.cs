using CleverRoom.Data;
using CleverRoom.Models;
using Microsoft.EntityFrameworkCore;

namespace CleverRoom.Services
{
    /// <summary>
    /// Работи на заден план и проверява на всеки 60 минути:
    /// - Обучения с изтекъл краен срок и недостатъчен брой участници → Canceled
    /// - Обучения, чиято начална дата е настъпила и са Published → Active
    /// - Обучения, чиято начална дата е минала и са Active → Completed
    /// </summary>
    public class TrainingStatusService : BackgroundService
    {
        private readonly IServiceScopeFactory _scopeFactory;
        private readonly ILogger<TrainingStatusService> _logger;
        private readonly TimeSpan _interval = TimeSpan.FromMinutes(60);

        public TrainingStatusService(
            IServiceScopeFactory scopeFactory,
            ILogger<TrainingStatusService> logger)
        {
            _scopeFactory = scopeFactory;
            _logger = logger;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            _logger.LogInformation("TrainingStatusService стартира.");

            while (!stoppingToken.IsCancellationRequested)
            {
                await ProcessTrainingsAsync();
                await Task.Delay(_interval, stoppingToken);
            }
        }

        private async Task ProcessTrainingsAsync()
        {
            using var scope = _scopeFactory.CreateScope();
            var db = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
            var now = DateTime.UtcNow;

            // 1. Автоматично отказване при недостатъчен брой участници след края на срока
            var toCancel = await db.Trainings
                .Include(t => t.Enrollments)
                .Where(t => t.Status == TrainingStatus.Published
                         && t.EnrollmentDeadline < now)
                .ToListAsync();

            foreach (var t in toCancel)
            {
                if (t.EnrolledCount < t.MinParticipants)
                {
                    t.Status = TrainingStatus.Canceled;
                    _logger.LogInformation(
                        "Обучение '{Title}' (Id={Id}) отказано – само {Count}/{Min} участника.",
                        t.Title, t.Id, t.EnrolledCount, t.MinParticipants);
                }
            }

            // 2. Published → Active при настъпила начална дата
            var toActivate = await db.Trainings
                .Where(t => t.Status == TrainingStatus.Published
                         && t.StartDate <= now
                         && t.EnrollmentDeadline < now)
                .ToListAsync();

            foreach (var t in toActivate)
            {
                if (t.Status != TrainingStatus.Canceled)
                {
                    t.Status = TrainingStatus.Active;
                    _logger.LogInformation("Обучение '{Title}' (Id={Id}) → Active.", t.Title, t.Id);
                }
            }

            // 3. Active → Completed при приключена начална дата + 8 часа
            var toComplete = await db.Trainings
                .Where(t => t.Status == TrainingStatus.Active
                         && t.StartDate.AddHours(8) < now)
                .ToListAsync();

            foreach (var t in toComplete)
            {
                t.Status = TrainingStatus.Completed;
                _logger.LogInformation("Обучение '{Title}' (Id={Id}) → Completed.", t.Title, t.Id);
            }

            var changed = toCancel.Count + toActivate.Count + toComplete.Count;
            if (changed > 0)
                await db.SaveChangesAsync();
        }
    }
}
