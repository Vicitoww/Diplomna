using System.ComponentModel.DataAnnotations;

namespace CleverRoom.Models.ViewModels
{
    public class RegisterViewModel
    {
        [Required(ErrorMessage = "Въведете пълно име.")]
        [Display(Name = "Пълно име")]
        public string FullName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Въведете имейл адрес.")]
        [EmailAddress(ErrorMessage = "Невалиден имейл адрес.")]
        [Display(Name = "Имейл")]
        public string Email { get; set; } = string.Empty;

        [Required(ErrorMessage = "Въведете парола.")]
        [MinLength(6, ErrorMessage = "Паролата трябва да е поне 6 символа.")]
        [DataType(DataType.Password)]
        [Display(Name = "Парола")]
        public string Password { get; set; } = string.Empty;

        [Required(ErrorMessage = "Потвърдете паролата.")]
        [DataType(DataType.Password)]
        [Compare(nameof(Password), ErrorMessage = "Паролите не съвпадат.")]
        [Display(Name = "Потвърди парола")]
        public string ConfirmPassword { get; set; } = string.Empty;
    }

    public class LoginViewModel
    {
        [Required(ErrorMessage = "Въведете имейл адрес.")]
        [EmailAddress]
        [Display(Name = "Имейл")]
        public string Email { get; set; } = string.Empty;

        [Required(ErrorMessage = "Въведете парола.")]
        [DataType(DataType.Password)]
        [Display(Name = "Парола")]
        public string Password { get; set; } = string.Empty;

        [Display(Name = "Запомни ме")]
        public bool RememberMe { get; set; }
    }

    public class TrainingFormViewModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Заглавието е задължително.")]
        [MaxLength(200)]
        [Display(Name = "Заглавие")]
        public string Title { get; set; } = string.Empty;

        [Required(ErrorMessage = "Описанието е задължително.")]
        [Display(Name = "Описание")]
        public string Description { get; set; } = string.Empty;

        [Required(ErrorMessage = "Датата на провеждане е задължителна.")]
        [Display(Name = "Дата на провеждане")]
        public DateTime StartDate { get; set; } = DateTime.Today.AddDays(7);

        [Required(ErrorMessage = "Крайният срок е задължителен.")]
        [Display(Name = "Краен срок за записване")]
        public DateTime EnrollmentDeadline { get; set; } = DateTime.Today.AddDays(5);

        [Range(1, 1000)]
        [Display(Name = "Минимален брой участници")]
        public int MinParticipants { get; set; } = 5;

        [Range(1, 1000)]
        [Display(Name = "Максимален брой участници")]
        public int MaxParticipants { get; set; } = 20;

        [Display(Name = "URL на изображение")]
        public string? ImageUrl { get; set; }

        [Display(Name = "URL на видео")]
        public string? VideoUrl { get; set; }

        [Display(Name = "Локация")]
        public string? Location { get; set; }
    }

    public class CommentFormViewModel
    {
        public int TrainingId { get; set; }

        [Required(ErrorMessage = "Коментарът не може да е празен.")]
        [MaxLength(1000)]
        [Display(Name = "Коментар")]
        public string Content { get; set; } = string.Empty;
    }

    public class ReviewFormViewModel
    {
        [Required(ErrorMessage = "Отзивът не може да е празен.")]
        [MaxLength(2000)]
        [Display(Name = "Отзив")]
        public string Content { get; set; } = string.Empty;

        [Range(1, 5)]
        [Display(Name = "Оценка (1–5)")]
        public int Rating { get; set; } = 5;
    }

    public class MyTrainingsViewModel
    {
        public IList<Training> AsAuthor { get; set; } = new List<Training>();
        public IList<Training> AsParticipant { get; set; } = new List<Training>();
        public IList<Training> Completed { get; set; } = new List<Training>();
    }
}
