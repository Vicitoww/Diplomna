using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CleverRoom.Models
{
    public enum TrainingStatus
    {
        PendingApproval,
        Published,
        Active,
        Completed,
        Canceled
    }

    public class Training
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Заглавието е задължително.")]
        [MaxLength(200)]
        public string Title { get; set; } = string.Empty;

        [Required(ErrorMessage = "Описанието е задължително.")]
        public string Description { get; set; } = string.Empty;

        [Required(ErrorMessage = "Датата на провеждане е задължителна.")]
        public DateTime StartDate { get; set; }

        [Required(ErrorMessage = "Крайният срок за записване е задължителен.")]
        public DateTime EnrollmentDeadline { get; set; }

        [Range(1, 1000, ErrorMessage = "Минималният брой участници трябва да е между 1 и 1000.")]
        public int MinParticipants { get; set; } = 1;

        [Range(1, 1000)]
        public int MaxParticipants { get; set; } = 20;

        public TrainingStatus Status { get; set; } = TrainingStatus.PendingApproval;

        public string? ImageUrl { get; set; }
        public string? VideoUrl { get; set; }
        public string? Location { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        [Required]
        public string AuthorId { get; set; } = string.Empty;

        [ForeignKey(nameof(AuthorId))]
        public ApplicationUser? Author { get; set; }

        public ICollection<Enrollment> Enrollments { get; set; } = new List<Enrollment>();
        public ICollection<Comment> Comments { get; set; } = new List<Comment>();

        public bool CanEnroll => Status == TrainingStatus.Published
                                && DateTime.UtcNow < EnrollmentDeadline
                                && Enrollments.Count < MaxParticipants;

        public int EnrolledCount => Enrollments.Count(e => e.IsActive);
    }
}
