using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CleverRoom.Models
{
    public class Enrollment
    {
        public int Id { get; set; }

        [Required]
        public string UserId { get; set; } = string.Empty;

        [ForeignKey(nameof(UserId))]
        public ApplicationUser? User { get; set; }

        public int TrainingId { get; set; }

        [ForeignKey(nameof(TrainingId))]
        public Training? Training { get; set; }

        public DateTime EnrolledAt { get; set; } = DateTime.UtcNow;
        public bool IsActive { get; set; } = true;
    }

    public class Comment
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Коментарът не може да е празен.")]
        [MaxLength(1000)]
        public string Content { get; set; } = string.Empty;

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public bool IsFlagged { get; set; } = false;
        public bool IsHidden { get; set; } = false;

        [Required]
        public string AuthorId { get; set; } = string.Empty;

        [ForeignKey(nameof(AuthorId))]
        public ApplicationUser? Author { get; set; }

        public int TrainingId { get; set; }

        [ForeignKey(nameof(TrainingId))]
        public Training? Training { get; set; }
    }

    public class Review
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Отзивът не може да е празен.")]
        [MaxLength(2000)]
        public string Content { get; set; } = string.Empty;

        [Range(1, 5, ErrorMessage = "Оценката трябва да е между 1 и 5.")]
        public int Rating { get; set; } = 5;

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public bool IsHidden { get; set; } = false;

        [Required]
        public string AuthorId { get; set; } = string.Empty;

        [ForeignKey(nameof(AuthorId))]
        public ApplicationUser? Author { get; set; }
    }
}
